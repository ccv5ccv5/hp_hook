# -*- encoding=utf8 -*-
__author__ = "cc"

from airtest.core.api import *

auto_setup(__file__)
